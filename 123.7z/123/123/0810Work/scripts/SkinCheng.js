﻿$(function () {
    //页面换肤
    $("#cssfile").attr("href", "styles/skin/" + $.cookie("key") + ".css");
    $("#" + $.cookie("key")).addClass("selected").siblings().removeClass("selected");
    $("#skin li").click(function () {
        $(this).addClass("selected").siblings().removeClass("selected");
        var cssName = $(this).attr("id");
        $("#cssfile").attr("href", "styles/skin/" + cssName + ".css");
        //设置cookie
        $.cookie("key", $(this).attr("id"), { path: "/", expires: 7 });
    });
});