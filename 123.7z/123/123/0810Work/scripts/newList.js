﻿//覆盖图片的详情
$(function () {
	//图片添加详情，动态添加覆盖在图片上
	//
	//$(".Listxiang").hide();
	$(".Listfont").hide();
	$(".Listxiang span").hide();
	$("#jnBrandList li").hover(function () {
		//$(this).find(".Listxiang").fadeIn();
		//显示背景
		$(this).find(".Listxiang").animate({ opacity: "1" }, 300);
		//显示字体
		$(".Listfont").fadeIn(0).animate({ top: "40px" }, 100);
		$(".Listxiang span").fadeIn(0).animate({ bottom: "65px" }, 200);
	}, function () {
		//$(this).find(".Listxiang").fadeOut();
		//字体归位隐藏
		$(".Listfont").fadeOut(300).animate({ top: "0px" }, 0).hide();
		//背景隐去
		$(this).find(".Listxiang").animate({ opacity: "0" }, 300);
	})
});