﻿$(function () {
    //置顶广告
    $("#ad img").hover(function () {
        $("#ad span").fadeIn(100);
    }).mouseout(function () {
        $("#ad span").fadeOut(100);
    })
    $("#ad span").click(function () {
        $("#ad").hide();
    })
})
