﻿$(function () {
  
    //返回顶部

    $(window).scroll(function () {
        console.log($(window).scrollTop());
        if ($(window).scrollTop() > 300) {
            $("#backTop").fadeIn(200);
        } else {
            $("#backTop").fadeOut(200);
        }
    });

    $("#backTop").click(function () {
        $("body").animate({ "scrollTop": 0 }, 500);
    })
})