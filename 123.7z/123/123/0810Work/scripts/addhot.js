﻿/* 添加hot显示 */
$(function(){
	$(".jnCatainfo .promoted").append('<s class="hot"></s>');
})